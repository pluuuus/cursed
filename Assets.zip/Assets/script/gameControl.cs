﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using UnityEngine.UI;


public class gameControl : MonoBehaviour {


	//initial curse array
	public GameObject[] curse11;
	public GameObject[] curse21;
	public GameObject[] curse31;

	public GameObject[] curse12;
	public GameObject[] curse22;
	public GameObject[] curse32;

	//player1
	public GameObject baozhatou1;
	public GameObject shefa1;
	public GameObject datou1;
	public GameObject baoshi1;
	public GameObject jianya1;
	public GameObject jianbizi1;
	public GameObject jianhuzi1;
	public GameObject maoerduo1;
	public GameObject xiongerduo1;
	public GameObject niujiao1;
	public GameObject unicorn1;
	public GameObject hetun1;
	public GameObject meimao1;
	public GameObject bianse1;
	public GameObject zhenzi1;

	//player2
	public GameObject shefa2;
	public GameObject baozhatou2;
	public GameObject datou2;
	public GameObject baoshi2;
	public GameObject jianya2;
	public GameObject jianbizi2;
	public GameObject jianhuzi2;
	public GameObject maoerduo2;
	public GameObject xiongerduo2;
	public GameObject niujiao2;
	public GameObject unicorn2;
	public GameObject hetun2;
	public GameObject meimao2;
	public GameObject bianse2;
	public GameObject zhenzi2;

	//icon for 2 players
	public GameObject icon1;
	public GameObject icon2;
	public GameObject icon3;
	public GameObject icon4;
	public GameObject icon5;
	public GameObject icon6;
	public GameObject icon7;
	public GameObject icon8;

	//curse icon
	public GameObject ci1;
	public GameObject ci2;
	public GameObject ci3;
	public GameObject ci4;
	public GameObject ci5;
	public GameObject ci6;
	public GameObject ci7;
	public GameObject ci8;
	public GameObject ci9;
	public GameObject ci10;
	public GameObject ci11;
	public GameObject ci12;
	public GameObject ci13;
	public GameObject ci14;
	public GameObject ci15;


	//pot smoke
	public GameObject smoke1;
	public GameObject smoke2;
	public GameObject smoke3;
	public GameObject smoke4;
	public GameObject smoke5;

	//pot
	public GameObject A;
	public GameObject B;
	public GameObject C;
	public GameObject D;

	//buttons
	// public GameObject button1;
	// public GameObject button2;
	// public GameObject button3;
	// public GameObject button4;

	//buttontime
	public float button1Time = 10.0f;
	private float button1NextTime = 0;
	public float button2Time = 10.0f;
	private float button2NextTime = 0;
	public float button3Time = 10.0f;
	private float button3NextTime = 0;
	public float button4Time = 10.0f;
	private float button4NextTime = 0;

	//potcooltime
	public float potTime = 5.0f;
	private float potNextTime = 0;

	//potioncooltime
	public float potionA1 = 10.0f;
	private float potionA1NextTime = 0;

	public float potionA2 = 10.0f;
	private float potionA2NextTime = 0;

	public float potionB1 = 10.0f;
	private float potionB1NextTime = 0;

	public float potionB2 = 10.0f;
	private float potionB2NextTime = 0;

	public float potionC1 = 10.0f;
	private float potionC1NextTime = 0;

	public float potionC2 = 10.0f;
	private float potionC2NextTime = 0;

	public float potionD1 = 10.0f;
	private float potionD1NextTime = 0;

	public float potionD2 = 10.0f;
	private float potionD2NextTime = 0;

	// public Slider potSlider;
	//pot time mapping
	float val;

	//potion slider
	public Slider potionA1Slider;
	public Slider potionA2Slider;
	public Slider potionB1Slider;
	public Slider potionB2Slider;
	public Slider potionC1Slider;
	public Slider potionC2Slider;
	public Slider potionD1Slider;
	public Slider potionD2Slider;

	//button slider
	public Slider button1Slider;
	public Slider button2Slider;
	public Slider button3Slider;
	public Slider button4Slider;


	//potion time mapping
	float valA1;
	float valA2;
	float valB1;
	float valB2;
	float valC1;
	float valC2;
	float valD1;
	float valD2;

	//button time mapping
	float valbutton1;
	float valbutton2;
	float valbutton3;
	float valbutton4;

	//player win
	public GameObject win1;
	public GameObject win2;

	// int count;
	//state
	// bool potState = true;


	void Awake () {
		

		//original curse
		GameObject[] curse11 = new GameObject[]{jianya1, datou1, meimao1, bianse1};
		int p11 = UnityEngine.Random.Range (0, 4);
		curse11[p11].SetActive(true);

		GameObject[] curse12 = new GameObject[]{jianya2, datou2, meimao2, bianse2};
		int p12 = UnityEngine.Random.Range (0, 4);
		curse12[p12].SetActive(true);

		GameObject[] curse21 = new GameObject[]{hetun1, niujiao1, unicorn1, meimao1, zhenzi1, shefa1};
		int p21 = UnityEngine.Random.Range (0, 6);
		curse21[p21].SetActive(true);

		GameObject[] curse22 = new GameObject[]{hetun2, niujiao2, unicorn2, maoerduo2, zhenzi2, shefa2};
		int p22 = UnityEngine.Random.Range (0, 6);
		curse22[p22].SetActive(true);

		GameObject[] curse31 = new GameObject[]{jianbizi1, jianhuzi1, baoshi1, xiongerduo1};
		int p31 = UnityEngine.Random.Range (0, 4);
		curse31[p31].SetActive(true);

		GameObject[] curse32 = new GameObject[]{jianbizi2, jianhuzi2, baoshi2, xiongerduo2};
		int p32 = UnityEngine.Random.Range (0, 4);
		curse32[p32].SetActive(true);

		// button1cool = gameObject.GetComponent<Image>();

	}

	
	// Update is called once per frame
	void FixedUpdate () {

		//reset the game
		if(Input.GetKeyDown(KeyCode.R)){
			SceneManager.LoadScene("Startscreen");
		}



		//Game Over
		if(baozhatou1.active == false && shefa1.active == false && datou1.active == false && baoshi1.active == false &&
			jianya1.active == false && jianbizi1.active == false && jianhuzi1.active == false && maoerduo1.active == false &&
			xiongerduo1.active == false && niujiao1.active == false && unicorn1.active == false && hetun1.active == false &&
			meimao1.active == false && bianse1.active == false && zhenzi1.active == false){
			//pic + press any button to start
			SceneManager.LoadScene("Player1win");
		}

		if(baozhatou2.active == false && shefa2.active == false && datou2.active == false && baoshi2.active == false &&
			jianya2.active == false && jianbizi2.active == false && jianhuzi2.active == false && maoerduo2.active == false &&
			xiongerduo2.active == false && niujiao2.active == false && unicorn2.active == false && hetun2.active == false &&
			meimao2.active == false && bianse2.active == false && zhenzi2.active == false){
			// Debug.Log("Player2 wins");
				// if(Input.GetKeyDown(KeyCode.H)){
			SceneManager.LoadScene("Player2win");
		}

		// if(A.activeSelf && B.activeSelf && C.activeSelf && D.activeSelf){

		// }else{

		if(Time.time > potionA1NextTime){
		if(Input.GetKeyDown(KeyCode.A)){
			if(A.activeSelf){

				}else{
					A.SetActive(true);
				}
				potionA1NextTime =Time.time + potionA1;
		}
		
	}

		if(Time.time > potionA2NextTime){
		if(Input.GetKeyDown(KeyCode.H)){
			if(A.activeSelf){

				}else{
					A.SetActive(true);
				}
				potionA2NextTime =Time.time + potionA2;
		}
	// 	potionA2NextTime =Time.time + potionA2;
	}


		if(Time.time > potionB1NextTime){
		if(Input.GetKeyDown(KeyCode.S)){
			if(B.activeSelf){

				}else{
					B.SetActive(true);
				}
				potionB1NextTime =Time.time + potionB1;
		}
		
	}

		if(Time.time > potionB2NextTime){
		if(Input.GetKeyDown(KeyCode.J)){
			if(B.activeSelf){

				}else{
					B.SetActive(true);
				}
				potionB2NextTime =Time.time + potionB2;
		}

	}

		if(Time.time > potionC1NextTime){
		if(Input.GetKeyDown(KeyCode.D)){
			if(C.activeSelf){

				}else{
					C.SetActive(true);
				}
				potionC1NextTime =Time.time + potionC1;
		}
	// 	
	}

		if(Time.time > potionC2NextTime){
		if(Input.GetKeyDown(KeyCode.K)){
			if(C.activeSelf){

				}else{
					C.SetActive(true);
				}
				potionC2NextTime =Time.time + potionC2;
		}
	// 	
	}

		if(Time.time > potionD1NextTime){
	if(Input.GetKeyDown(KeyCode.F)){
			if(D.activeSelf){

				}else{
					D.SetActive(true);
				}
				potionD1NextTime =Time.time + potionD1;
		}

	}

		if(Time.time > potionD2NextTime){
		if(Input.GetKeyDown(KeyCode.L)){
			if(D.activeSelf){

				}else{
					D.SetActive(true);
				}
				potionD2NextTime =Time.time + potionD2;
		}
		
	}
// }



		// if(Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.H) || Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.J)
		// 	|| Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.K) || Input.GetKeyDown(KeyCode.F) || Input.GetKeyDown(KeyCode.L)){
		// 	potNextTime = Time.time + potTime;
		// }
		
if(A.activeSelf && B.activeSelf && C.activeSelf && D.activeSelf){
			ci1.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(A.activeSelf && B.activeSelf && C.activeSelf){
			ci2.SetActive(true);
			ci1.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(A.activeSelf && B.activeSelf && D.activeSelf){
			ci3.SetActive(true);
			ci2.SetActive(false);
			ci1.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(A.activeSelf && D.activeSelf && C.activeSelf){
			ci4.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci1.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(D.activeSelf && B.activeSelf && C.activeSelf){
			ci5.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci1.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(A.activeSelf && B.activeSelf){
			ci6.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci1.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(A.activeSelf && C.activeSelf){
			ci7.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci1.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(A.activeSelf && D.activeSelf){
			ci8.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci1.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(C.activeSelf && B.activeSelf){
			ci9.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci1.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(D.activeSelf && B.activeSelf){
			ci10.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci1.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(C.activeSelf && D.activeSelf){
			ci11.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci1.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(A.activeSelf){
			ci12.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci1.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(B.activeSelf){
			ci13.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci1.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
			}else if(C.activeSelf){
			ci14.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci11.SetActive(false);
			ci15.SetActive(false);
			}else if(D.activeSelf){
			ci15.SetActive(true);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci11.SetActive(false);
			}


if(Time.time > potNextTime){
	if(Time.time > button1NextTime){
		if(Input.GetKeyDown(KeyCode.Z)){
			// if(potState = true){
			if(A.activeSelf && B.activeSelf && C.activeSelf && D.activeSelf){
				if(baozhatou1.activeSelf){
					baozhatou1.SetActive(false);
				}else{
					baozhatou1.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf && C.activeSelf){
				if(jianbizi1.activeSelf){
					jianbizi1.SetActive(false);
				}else{
					jianbizi1.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf && D.activeSelf){
				if(baoshi1.activeSelf){
					baoshi1.SetActive(false);
				}else{
					baoshi1.SetActive(true);
				}
			}else if(A.activeSelf && D.activeSelf && C.activeSelf){
				if(jianhuzi1.activeSelf){
					jianhuzi1.SetActive(false);
				}else{
					jianhuzi1.SetActive(true);
				}
			}else if(D.activeSelf && B.activeSelf && C.activeSelf){
				if(xiongerduo1.activeSelf){
					xiongerduo1.SetActive(false);
				}else{
					xiongerduo1.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf){
				if(hetun1.activeSelf){
					hetun1.SetActive(false);
				}else{
					hetun1.SetActive(true);
				}
			}else if(A.activeSelf && C.activeSelf){
				if(niujiao1.activeSelf){
					niujiao1.SetActive(false);
				}else{
					niujiao1.SetActive(true);
				}
			}else if(A.activeSelf && D.activeSelf){
				if(unicorn1.activeSelf){
					unicorn1.SetActive(false);
				}else{
					unicorn1.SetActive(true);
				}
			}else if(C.activeSelf && B.activeSelf){
				if(maoerduo1.activeSelf){
					maoerduo1.SetActive(false);
				}else{
					maoerduo1.SetActive(true);
				}
			}else if(D.activeSelf && B.activeSelf){
				if(zhenzi1.activeSelf){
					zhenzi1.SetActive(false);
				}else{
					zhenzi1.SetActive(true);
				}
			}else if(C.activeSelf && D.activeSelf){
				if(shefa1.activeSelf){
					shefa1.SetActive(false);
				}else{
					shefa1.SetActive(true);
				}
			}else if(A.activeSelf){
				if(jianya1.activeSelf){
					jianya1.SetActive(false);
				}else{
					jianya1.SetActive(true);
				}
			}else if(B.activeSelf){
				if(datou1.activeSelf){
					datou1.SetActive(false);
				}else{
					datou1.SetActive(true);
				}
			}else if(C.activeSelf){
				if(meimao1.activeSelf){
					meimao1.SetActive(false);
				}else{
					meimao1.SetActive(true);
				}
			}else if(D.activeSelf){
				if(bianse1.activeSelf){
					bianse1.SetActive(false);
				}else{
					bianse1.SetActive(true);
				}
			}

			A.SetActive(false);
			B.SetActive(false);
			C.SetActive(false);
			D.SetActive(false);
		// }
			button1NextTime = Time.time + button1Time;
		// 	potNextTime = Time.time + potTime;
			ci1.SetActive(false);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
		}
	}
	}

	if(Time.time > potNextTime){
		if(Time.time > button4NextTime){
		if(Input.GetKeyDown(KeyCode.M)){
			// if(potState = true){
			if(A.activeSelf && B.activeSelf && C.activeSelf && D.activeSelf){
				if(baozhatou1.activeSelf){
					baozhatou1.SetActive(false);
				}else{
					baozhatou1.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf && C.activeSelf){
				if(jianbizi1.activeSelf){
					jianbizi1.SetActive(false);
				}else{
					jianbizi1.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf && D.activeSelf){
				if(baoshi1.activeSelf){
					baoshi1.SetActive(false);
				}else{
					baoshi1.SetActive(true);
				}
			}else if(A.activeSelf && D.activeSelf && C.activeSelf){
				if(jianhuzi1.activeSelf){
					jianhuzi1.SetActive(false);
				}else{
					jianhuzi1.SetActive(true);
				}
			}else if(D.activeSelf && B.activeSelf && C.activeSelf){
				if(xiongerduo1.activeSelf){
					xiongerduo1.SetActive(false);
				}else{
					xiongerduo1.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf){
				if(hetun1.activeSelf){
					hetun1.SetActive(false);
				}else{
					hetun1.SetActive(true);
				}
			}else if(A.activeSelf && C.activeSelf){
				if(niujiao1.activeSelf){
					niujiao1.SetActive(false);
				}else{
					niujiao1.SetActive(true);
				}
			}else if(A.activeSelf && D.activeSelf){
				if(unicorn1.activeSelf){
					unicorn1.SetActive(false);
				}else{
					unicorn1.SetActive(true);
				}
			}else if(C.activeSelf && B.activeSelf){
				if(maoerduo1.activeSelf){
					maoerduo1.SetActive(false);
				}else{
					maoerduo1.SetActive(true);
				}
			}else if(D.activeSelf && B.activeSelf){
				if(zhenzi1.activeSelf){
					zhenzi1.SetActive(false);
				}else{
					zhenzi1.SetActive(true);
				}
			}else if(C.activeSelf && D.activeSelf){
				if(shefa1.activeSelf){
					shefa1.SetActive(false);
				}else{
					shefa1.SetActive(true);
				}
			}else if(A.activeSelf){
				if(jianya1.activeSelf){
					jianya1.SetActive(false);
				}else{
					jianya1.SetActive(true);
				}
			}else if(B.activeSelf){
				if(datou1.activeSelf){
					datou1.SetActive(false);
				}else{
					datou1.SetActive(true);
				}
			}else if(C.activeSelf){
				if(meimao1.activeSelf){
					meimao1.SetActive(false);
				}else{
					meimao1.SetActive(true);
				}
			}else if(D.activeSelf){
				if(bianse1.activeSelf){
					bianse1.SetActive(false);
				}else{
					bianse1.SetActive(true);
				}
			}

			A.SetActive(false);
			B.SetActive(false);
			C.SetActive(false);
			D.SetActive(false);
		// }

		// 	potNextTime = Time.time + potTime;
			button4NextTime = Time.time + button4Time;

			ci1.SetActive(false);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
		}
	}
	}

	float barvalue = potNextTime - Time.time;
	float barA1value = potionA1NextTime - Time.time;
	float barA2value = potionA2NextTime - Time.time;
	float barB1value = potionB1NextTime - Time.time;
	float barB2value = potionB2NextTime - Time.time;
	float barC1value = potionC1NextTime - Time.time;
	float barC2value = potionC2NextTime - Time.time;
	float barD1value = potionD1NextTime - Time.time;
	float barD2value = potionD2NextTime - Time.time;

	float barButton1Value = button1NextTime - Time.time;
	float barButton2Value = button2NextTime - Time.time;
	float barButton3Value = button3NextTime - Time.time;
	float barButton4Value = button4NextTime - Time.time;
	// Debug.Log(barvalue);


if(Time.time > potNextTime){
	if(Time.time > button3NextTime){
		if(Input.GetKeyDown(KeyCode.N)){
			// if(potState == true){
			if(A.activeSelf && B.activeSelf && C.activeSelf && D.activeSelf){
				// ci1.SetActive(true);
				if(baozhatou2.activeSelf){
					baozhatou2.SetActive(false);
				}else{
					baozhatou2.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf && C.activeSelf){
				// ci2.SetActive(true);
				if(jianbizi2.activeSelf){
					jianbizi2.SetActive(false);
				}else{
					jianbizi2.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf && D.activeSelf){
				if(baoshi2.activeSelf){
					baoshi2.SetActive(false);
				}else{
					baoshi2.SetActive(true);
				}
			}else if(A.activeSelf && D.activeSelf && C.activeSelf){
				if(jianhuzi2.activeSelf){
					jianhuzi2.SetActive(false);
				}else{
					jianhuzi2.SetActive(true);
				}
			}else if(D.activeSelf && B.activeSelf && C.activeSelf){
				if(xiongerduo2.activeSelf){
					xiongerduo2.SetActive(false);
				}else{
					xiongerduo2.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf){
				if(hetun2.activeSelf){
					hetun2.SetActive(false);
				}else{
					hetun2.SetActive(true);
				}
			}else if(A.activeSelf && C.activeSelf){
				if(niujiao2.activeSelf){
					niujiao2.SetActive(false);
				}else{
					niujiao2.SetActive(true);
				}
			}else if(A.activeSelf && D.activeSelf){
				if(unicorn2.activeSelf){
					unicorn2.SetActive(false);
				}else{
					unicorn2.SetActive(true);
				}
			}else if(C.activeSelf && B.activeSelf){
				if(maoerduo2.activeSelf){
					maoerduo2.SetActive(false);
				}else{
					maoerduo2.SetActive(true);
				}
			}else if(D.activeSelf && B.activeSelf){
				if(zhenzi2.activeSelf){
					zhenzi2.SetActive(false);
				}else{
					zhenzi2.SetActive(true);
				}
			}else if(C.activeSelf && D.activeSelf){
				if(shefa2.activeSelf){
					shefa2.SetActive(false);
				}else{
					shefa2.SetActive(true);
				}
			}else if(A.activeSelf){
				if(jianya2.activeSelf){
					jianya2.SetActive(false);
				}else{
					jianya2.SetActive(true);
				}
			}else if(B.activeSelf){
				if(datou2.activeSelf){
					datou2.SetActive(false);
				}else{
					datou2.SetActive(true);
				}
			}else if(C.activeSelf){
				if(meimao2.activeSelf){
					meimao2.SetActive(false);
				}else{
					meimao2.SetActive(true);
				}
			}else if(D.activeSelf){
				if(bianse2.activeSelf){
					bianse2.SetActive(false);
				}else{
					bianse2.SetActive(true);
				}
			}

			A.SetActive(false);
			B.SetActive(false);
			C.SetActive(false);
			D.SetActive(false);
		// }
		// 	potNextTime = Time.time + potTime;
			button3NextTime = Time.time + button3Time;

			ci1.SetActive(false);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
		}
	}
	}

	if(Time.time > potNextTime){
			if(Time.time > button2NextTime){
		if(Input.GetKeyDown(KeyCode.X)){
			// if(potState == true){
			if(A.activeSelf && B.activeSelf && C.activeSelf && D.activeSelf){
				ci1.SetActive(true);
				if(baozhatou2.activeSelf){
					baozhatou2.SetActive(false);
				}else{
					baozhatou2.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf && C.activeSelf){
				ci2.SetActive(true);
				if(jianbizi2.activeSelf){
					jianbizi2.SetActive(false);
				}else{
					jianbizi2.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf && D.activeSelf){
				if(baoshi2.activeSelf){
					baoshi2.SetActive(false);
				}else{
					baoshi2.SetActive(true);
				}
			}else if(A.activeSelf && D.activeSelf && C.activeSelf){
				if(jianhuzi2.activeSelf){
					jianhuzi2.SetActive(false);
				}else{
					jianhuzi2.SetActive(true);
				}
			}else if(D.activeSelf && B.activeSelf && C.activeSelf){
				if(xiongerduo2.activeSelf){
					xiongerduo2.SetActive(false);
				}else{
					xiongerduo2.SetActive(true);
				}
			}else if(A.activeSelf && B.activeSelf){
				if(hetun2.activeSelf){
					hetun2.SetActive(false);
				}else{
					hetun2.SetActive(true);
				}
			}else if(A.activeSelf && C.activeSelf){
				if(niujiao2.activeSelf){
					niujiao2.SetActive(false);
				}else{
					niujiao2.SetActive(true);
				}
			}else if(A.activeSelf && D.activeSelf){
				if(unicorn2.activeSelf){
					unicorn2.SetActive(false);
				}else{
					unicorn2.SetActive(true);
				}
			}else if(C.activeSelf && B.activeSelf){
				if(maoerduo2.activeSelf){
					maoerduo2.SetActive(false);
				}else{
					maoerduo2.SetActive(true);
				}
			}else if(D.activeSelf && B.activeSelf){
				if(zhenzi2.activeSelf){
					zhenzi2.SetActive(false);
				}else{
					zhenzi2.SetActive(true);
				}
			}else if(C.activeSelf && D.activeSelf){
				if(shefa2.activeSelf){
					shefa2.SetActive(false);
				}else{
					shefa2.SetActive(true);
				}
			}else if(A.activeSelf){
				if(jianya2.activeSelf){
					jianya2.SetActive(false);
				}else{
					jianya2.SetActive(true);
				}
			}else if(B.activeSelf){
				if(datou2.activeSelf){
					datou2.SetActive(false);
				}else{
					datou2.SetActive(true);
				}
			}else if(C.activeSelf){
				if(meimao2.activeSelf){
					meimao2.SetActive(false);
				}else{
					meimao2.SetActive(true);
				}
			}else if(D.activeSelf){
				if(bianse2.activeSelf){
					bianse2.SetActive(false);
				}else{
					bianse2.SetActive(true);
				}
			}

			A.SetActive(false);
			B.SetActive(false);
			C.SetActive(false);
			D.SetActive(false);
		// }
		// 	potNextTime = Time.time + potTime;
			button2NextTime = Time.time + button2Time;

			ci1.SetActive(false);
			ci2.SetActive(false);
			ci3.SetActive(false);
			ci4.SetActive(false);
			ci5.SetActive(false);
			ci6.SetActive(false);
			ci7.SetActive(false);
			ci8.SetActive(false);
			ci9.SetActive(false);
			ci10.SetActive(false);
			ci11.SetActive(false);
			ci12.SetActive(false);
			ci13.SetActive(false);
			ci14.SetActive(false);
			ci15.SetActive(false);
		}
	}
	}

	if(A.activeSelf && B.activeSelf && C.activeSelf && D.activeSelf){

	}else{
			if(Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.F)
			|| Input.GetKeyDown(KeyCode.H) || Input.GetKeyDown(KeyCode.J) || Input.GetKeyDown(KeyCode.K) || Input.GetKeyDown(KeyCode.L)){
			potNextTime = Time.time + potTime;
		}
	}
		// if(Input.GetKeyDown(KeyCode.N) || Input.GetKeyDown(KeyCode.X) || Input.GetKeyDown(KeyCode.Z) || Input.GetKeyDown(KeyCode.M)){
		// 	potTime -= Time.deltaTime;
		// 	if(potTime <= 0){
		// 		potState = true;
		// 		potTime = 8.0f;
		// 	}
		// }
		// Debug.Log(potState);
	// potSlider.value = val;
	if(barvalue >= 0){
	// val = map(barvalue, 0f, 5f, 0f, 1f);
		if(barvalue <= 0){
			smoke1.SetActive(true);
			smoke2.SetActive(false);
			smoke3.SetActive(false);
			smoke4.SetActive(false);
			smoke5.SetActive(false);
			}else if(barvalue <= 1){
			smoke1.SetActive(false);
			smoke2.SetActive(true);
			smoke3.SetActive(false);
			smoke4.SetActive(false);
			smoke5.SetActive(false);

				}else if(barvalue <= 2){
			smoke1.SetActive(false);
			smoke2.SetActive(false);
			smoke3.SetActive(true);
			smoke4.SetActive(false);
			smoke5.SetActive(false);

					}else if(barvalue <= 3){
			smoke1.SetActive(false);
			smoke2.SetActive(false);
			smoke3.SetActive(false);
			smoke4.SetActive(true);
			smoke5.SetActive(false);

						}else if(barvalue <= 4){
			smoke1.SetActive(false);
			smoke2.SetActive(false);
			smoke3.SetActive(false);
			smoke4.SetActive(false);
			smoke5.SetActive(true);
						}

						
}

if(Input.GetKeyDown(KeyCode.Z) || Input.GetKeyDown(KeyCode.X) || Input.GetKeyDown(KeyCode.N) || Input.GetKeyDown(KeyCode.M)){
			smoke1.SetActive(false);
			smoke2.SetActive(false);
			smoke3.SetActive(false);
			smoke4.SetActive(false);
			smoke5.SetActive(false);
						}
		// Debug.Log(barButton1Value);-shizhege

	button1Slider.value = valbutton1;
	if(barButton1Value >= 0){
		valbutton1 = map(barButton1Value, 0f, 10f, 0f, 1f);
		// button1cool.fillAmount = valbutton1;
	}

	button2Slider.value = valbutton2;
	if(barButton2Value >= 0){
		valbutton2 = map(barButton2Value, 0f, 10f, 0f, 1f);
		// button1cool.fillAmount = valbutton1;
	}

	button3Slider.value = valbutton3;
	if(barButton3Value >= 0){
		valbutton3 = map(barButton3Value, 0f, 10f, 0f, 1f);
		// button1cool.fillAmount = valbutton1;
	}

	button4Slider.value = valbutton4;
	if(barButton4Value >= 0){
		valbutton4 = map(barButton4Value, 0f, 10f, 0f, 1f);
		// button1cool.fillAmount = valbutton1;
	}


	potionA1Slider.value = valA1;
	if(barA1value >= 0){
	valA1 = map(barA1value, 0f, 8f, 0f, 1f);
	}

	if(valA1 <= 0){
		icon1.SetActive(true);
	}else{
		icon1.SetActive(false);
	}

	potionB1Slider.value = valB1;
	if(barB1value >= 0){
	valB1 = map(barB1value, 0f, 10f, 0f, 1f);
	}

	if(valB1 <= 0){
		icon2.SetActive(true);
	}else{
		icon2.SetActive(false);
	}

	potionA2Slider.value = valA2;
	if(barA2value >= 0){
	valA2 = map(barA2value, 0f, 10f, 0f, 1f);
	}

	if(valA2 <= 0){
		icon5.SetActive(true);
	}else{
		icon5.SetActive(false);
	}

	potionB2Slider.value = valB2;
	if(barB2value >= 0){
	valB2 = map(barB2value, 0f, 10f, 0f, 1f);
	}

	if(valB2 <= 0){
		icon6.SetActive(true);
	}else{
		icon6.SetActive(false);
	}

	potionC1Slider.value = valC1;
	if(barC1value >= 0){
	valC1 = map(barC1value, 0f, 10f, 0f, 1f);
	}

	if(valC1 <= 0){
		icon3.SetActive(true);
	}else{
		icon3.SetActive(false);
	}

	potionC2Slider.value = valC2;
	if(barC2value >= 0){
	valC2 = map(barC2value, 0f, 10f, 0f, 1f);
	}

	if(valC2 <= 0){
		icon7.SetActive(true);
	}else{
		icon7.SetActive(false);
	}

	potionD1Slider.value = valD1;
	if(barD1value >= 0){
	valD1 = map(barD1value, 0f, 10f, 0f, 1f);
	}

	if(valD1 <= 0){
		icon4.SetActive(true);
	}else{
		icon4.SetActive(false);
	}

	potionD2Slider.value = valD2;
	if(barD2value >= 0){
	valD2 = map(barD2value, 0f, 10f, 0f, 1f);
	}

	if(valD2 <= 0){
		icon8.SetActive(true);
	}else{
		icon8.SetActive(false);
	}
}

	// }

	float map(float v, float i1, float i2, float o1, float o2){
		return o1 + (v - i1) * (o2 - o1)/(i2 - i1);

	}


	// IEnumerator potCold(){
	// 	while(true){
	// 		yield return new WaitForSeconds(5.0f);
	// 	}
	// }
}
