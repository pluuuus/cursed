﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class startGame : MonoBehaviour {


	
	// Update is called once per frame
	void FixedUpdate () {



		if(Input.GetKeyDown(KeyCode.R)){
					Debug.Log("new scene");
				}

		if(Input.anyKey){
				SceneManager.LoadScene("MainGame");
		}
	}


}
