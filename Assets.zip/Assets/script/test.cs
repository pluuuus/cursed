﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test : MonoBehaviour {

 
    void Start () {

        string[] curse1 = new string[]{"A","B","C","D"};
        int p11 = Random.Range (0, 4);
        int p12 = Random.Range (0, 4);
        string[] curse2 = new string[]{"AB","AC","AD","BC","BD","CD"};
        int p21 = Random.Range (0, 6);
        int p22 = Random.Range (0, 6);
        string[] curse3 = new string[]{"ABC","ABD","ACD","BCD"};
        int p31 = Random.Range (0, 4);
        int p32 = Random.Range (0, 4);
        Debug.Log("Player 1:" + curse1[p11] + ", " + curse2[p21] + ", " + curse3[p31] + "; " + "Player2: " + curse1[p12] + ", " + curse2[p22] + ", " + curse3[p32]);

     }


     void Update(){
        
     }
}
