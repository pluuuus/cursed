﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class test2 : MonoBehaviour {

	public List<string> player1;
	public List<string> player2;
	public List<string> pot; 

	// int size = pot.Count;

	//if pot finished cold down
	bool potstate = true;
	// public float player1A = 2f;

	//if already added same potion to pot
	bool potionA = true;
	bool potionB = true;
	bool potionC = true;
	bool potionD = true;

	bool addstate = true;

	float potcoldtime = 10f;
	// float player1cold;
	// float player2cold;

	public int potionAcoldtime = 20;
	public Text potionAText;

	public int potionBcoldtime = 20;
	public Text potionBText;

	public int potionCcoldtime = 20;
	public Text potionCText;

	public int potionDcoldtime = 20;
	public Text potionDText;

	// public int potcoldtime = 5;
	// public Text potText;

	// public int player1coldtime = 5;
	// public Text player1Text;

	// public int player2coldtime = 5;
	// public Text player2Text;


	// Use this for initialization
	void Awake () {

		//original curses for two player
		string[] curse1 = new string[]{"A","B","C","D"};
        int p11 = Random.Range (0, 4);
        int p12 = Random.Range (0, 4);

        string[] curse2 = new string[]{"AB","AC","AD","BC","BD","CD"};
        int p21 = Random.Range (0, 6);
        int p22 = Random.Range (0, 6);

        string[] curse3 = new string[]{"ABC","ABD","ACD","BCD"};
        int p31 = Random.Range (0, 4);
        int p32 = Random.Range (0, 4);

        player1.Add(curse1[p11]);
        player1.Add(curse2[p21]);
        player1.Add(curse3[p31]);

        player2.Add(curse1[p12]);
        player2.Add(curse2[p22]);
        player2.Add(curse3[p32]);

		
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		

		//press button to add potion to pot list
		if(Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.H)){
			if(potionA = true){
			if(pot.Contains("A")){

				}else{
					potionA = false;
					pot.Add("A");
					StartCoroutine(curseround1());

					potionAcoldtime = 20;
				}

				
			}else{
				Debug.Log("no");
			}
		// 	if(potionA == true){
		// 	pot.Add("A");
		// 	//potion cold down
		// 	StartCoroutine(curseround1());
		// }

		}else if(Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.J)){
		// 	if(potionB == true){
		// 	pot.Add("B");
		// 	StartCoroutine(curseround2());
		// }
			if(potionB = true){
			if(pot.Contains("B")){

				}else{
					potionB = false;
					pot.Add("B");
					StartCoroutine(curseround2());

					potionBcoldtime = 20;
				}
				}else{
					Debug.Log("no2");
				}
		}else if(Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.K)){
		// 	if(potionC == true){
		// 	pot.Add("C");
		// 	StartCoroutine(curseround3());
		// }
			if(potionC = true){
			if(pot.Contains("C")){

				}else{
					potionC = false;
					pot.Add("C");
					StartCoroutine(curseround3());

					potionCcoldtime = 20;
				}
				}else{
					Debug.Log("no3");
				}
		}else if(Input.GetKeyDown(KeyCode.F) || Input.GetKeyDown(KeyCode.L)){
		// 	if(potionD == true){
		// 	pot.Add("D");
		// 	StartCoroutine(curseround4());
		// }
			if(potionD = true){
			if(pot.Contains("D")){

				}else{
					potionD = false;
					pot.Add("D");
					StartCoroutine(curseround4());

					potionDcoldtime = 20;
				}
				}else{
					Debug.Log("no4");
				}
	}
		
		
		if(potionAcoldtime >= 1){
					potionA = false;
					}else{
						potionA = true;
					}
		if(potionBcoldtime >= 1){
					potionB = false;
					}else{
						potionB = true;
					}
		if(potionCcoldtime >= 1){
					potionC = false;
					}else{
						potionC = true;
					}
		if(potionDcoldtime >= 1){
					potionD = false;
					}else{
						potionD = true;
					}

		//pot start cold down timer 
		// if(pot.Count > 0){
		// 	StartCoroutine(potcold());
		// 	potstate = true;
		// }

		

		// if(player1.Contains("A")){
		// 	Debug.Log("yes");
		// }
		if(potstate == true){

			if(Input.GetKeyDown(KeyCode.Z) || Input.GetKeyDown(KeyCode.M)){
				if(pot.Contains("A") && pot.Contains("B") && pot.Contains("C") && pot.Contains("D")){
			// Debug.Log("step1");
			if(addstate == true){
			if (player1.Contains("ABCD")){
				player1.Remove("ABCD");
				addstate = false;
			}else{
				player1.Add("ABCD");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("B") && pot.Contains("C")){
			if(addstate == true){
			if (player1.Contains("ABC")){
				player1.Remove("ABC");
				addstate = false;
			}else{
				player1.Add("ABC");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("B") && pot.Contains("D")){
			if(addstate == true){
			if (player1.Contains("ABD")){
				player1.Remove("ABD");
				addstate = false;
			}else{
				player1.Add("ABD");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("C") && pot.Contains("D")){
			if(addstate == true){
			if (player1.Contains("ACD")){
				player1.Remove("ACD");
				addstate = false;
			}else{
				player1.Add("ACD");
				addstate = false;
			}
		}
		}else if(pot.Contains("B") && pot.Contains("C") && pot.Contains("D")){
			if(addstate == true){
			if (player1.Contains("BCD")){
				player1.Remove("BCD");
				addstate = false;
			}else{
				player1.Add("BCD");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("B")){
			if(addstate == true){
			if (player1.Contains("AB")){
				player1.Remove("AB");
				addstate = false;
			}else{
				player1.Add("AB");
				addstate = false;
			}
		}
		}else if(pot.Contains("C") && pot.Contains("B")){
			if(addstate == true){
			if (player1.Contains("BC")){
				player1.Remove("BC");
				addstate = false;
			}else{
				player1.Add("BC");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("C")){
			if(addstate == true){
			if (player1.Contains("AC")){
				player1.Remove("AC");
				addstate = false;
			}else{
				player1.Add("AC");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("D")){
			if(addstate == true){
			if (player1.Contains("AD")){
				player1.Remove("AD");
				addstate = false;
			}else{
				player1.Add("AD");
				addstate = false;
			}
		}
		}else if(pot.Contains("D") && pot.Contains("B")){
			if(addstate == true){
			if (player1.Contains("BD")){
				player1.Remove("BD");
				addstate = false;
			}else{
				player1.Add("BD");
				addstate = false;
			}
		}
		}else if(pot.Contains("C") && pot.Contains("D")){
			if(addstate == true){
			if (player1.Contains("CD")){
				player1.Remove("CD");
				addstate = false;
			}else{
				player1.Add("CD");
				addstate = false;
			}
		}
		}else if(pot.Contains("A")){
			if(addstate == true){
			if (player1.Contains("A")){
				player1.Remove("A");
				addstate = false;
			}else{
				player1.Add("A");
				addstate = false;
			}
		}
		}else if(pot.Contains("B")){
			if(addstate == true){
			if (player1.Contains("B")){
				player1.Remove("B");
				addstate = false;
			}else{
				player1.Add("B");
				addstate = false;
			}
		}
		}else if(pot.Contains("C")){
			if(addstate == true){
			if (player1.Contains("C")){
				player1.Remove("C");
				addstate = false;
			}else{
				player1.Add("C");
				addstate = false;
			}
		}
		}else if(pot.Contains("D")){
			if(addstate == true){
			if (player1.Contains("D")){
				player1.Remove("D");
				addstate = false;
			}else{
				player1.Add("D");
				addstate = false;
			}
		}
		}


		pot.Remove("A");
				pot.Remove("B");
				pot.Remove("C");
				pot.Remove("D");
				addstate = true;

		}
			
			
		
		if(Input.GetKeyDown(KeyCode.X) || Input.GetKeyDown(KeyCode.N)){
				if(pot.Contains("A") && pot.Contains("B") && pot.Contains("C") && pot.Contains("D")){
			// Debug.Log("step1");
			if(addstate == true){
			if (player2.Contains("ABCD")){
				player2.Remove("ABCD");
				addstate = false;
			}else{
				player2.Add("ABCD");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("B") && pot.Contains("C")){
			if(addstate == true){
			if (player2.Contains("ABC")){
				player2.Remove("ABC");
				addstate = false;
			}else{
				player2.Add("ABC");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("B") && pot.Contains("D")){
			if(addstate == true){
			if (player2.Contains("ABD")){
				player2.Remove("ABD");
				addstate = false;
			}else{
				player2.Add("ABD");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("C") && pot.Contains("D")){
			if(addstate == true){
			if (player2.Contains("ACD")){
				player2.Remove("ACD");
				addstate = false;
			}else{
				player2.Add("ACD");
				addstate = false;
			}
		}
		}else if(pot.Contains("B") && pot.Contains("C") && pot.Contains("D")){
			if(addstate == true){
			if (player2.Contains("BCD")){
				player2.Remove("BCD");
				addstate = false;
			}else{
				player2.Add("BCD");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("B")){
			if(addstate == true){
			if (player2.Contains("AB")){
				player2.Remove("AB");
				addstate = false;
			}else{
				player2.Add("AB");
				addstate = false;
			}
		}
		}else if(pot.Contains("C") && pot.Contains("B")){
			if(addstate == true){
			if (player2.Contains("BC")){
				player2.Remove("BC");
				addstate = false;
			}else{
				player2.Add("BC");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("C")){
			if(addstate == true){
			if (player2.Contains("AC")){
				player2.Remove("AC");
				addstate = false;
			}else{
				player2.Add("AC");
				addstate = false;
			}
		}
		}else if(pot.Contains("A") && pot.Contains("D")){
			if(addstate == true){
			if (player2.Contains("AD")){
				player2.Remove("AD");
				addstate = false;
			}else{
				player2.Add("AD");
				addstate = false;
			}
		}
		}else if(pot.Contains("D") && pot.Contains("B")){
			if(addstate == true){
			if (player2.Contains("BD")){
				player2.Remove("BD");
				addstate = false;
			}else{
				player2.Add("BD");
				addstate = false;
			}
		}
		}else if(pot.Contains("C") && pot.Contains("D")){
			if(addstate == true){
			if (player2.Contains("CD")){
				player2.Remove("CD");
				addstate = false;
			}else{
				player2.Add("CD");
				addstate = false;
			}
		}
		}else if(pot.Contains("A")){
			if(addstate == true){
			if (player2.Contains("A")){
				player2.Remove("A");
				addstate = false;
			}else{
				player2.Add("A");
				addstate = false;
			}
		}
		}else if(pot.Contains("B")){
			if(addstate == true){
			if (player2.Contains("B")){
				player2.Remove("B");
				addstate = false;
			}else{
				player2.Add("B");
				addstate = false;
			}
		}
		}else if(pot.Contains("C")){
			if(addstate == true){
			if (player2.Contains("C")){
				player2.Remove("C");
				addstate = false;
			}else{
				player2.Add("C");
				addstate = false;
			}
		}
		}else if(pot.Contains("D")){
			if(addstate == true){
			if (player2.Contains("D")){
				player2.Remove("D");
				addstate = false;
			}else{
				player2.Add("D");
				addstate = false;
			}
		}
		}
				pot.Remove("A");
				pot.Remove("B");
				pot.Remove("C");
				pot.Remove("D");
				addstate = true;

		}
			}
		

		potionAText.text = ("potionA left time: " + potionAcoldtime);
		if (potionAcoldtime <= 0){
			StopCoroutine(curseround1());
			potionAText.text = "potionA is ready";
		}

		potionBText.text = ("potionB left time: " + potionBcoldtime);
		if (potionBcoldtime <= 0){
			StopCoroutine(curseround2());
			potionBText.text = "potionB is ready";
		}

		potionCText.text = ("potionC left time: " + potionCcoldtime);
		if (potionCcoldtime <= 0){
			StopCoroutine(curseround3());
			potionCText.text = "potionC is ready";
		}

		potionDText.text = ("potionD left time: " + potionDcoldtime);
		if (potionDcoldtime <= 0){
			StopCoroutine(curseround4());
			potionDText.text = "potionD is ready";
		}
			if(Input.GetKeyDown(KeyCode.Z) || Input.GetKeyDown(KeyCode.M) || Input.GetKeyDown(KeyCode.X) || Input.GetKeyDown(KeyCode.N)){
			potstate = false;
			StartCoroutine(potcold());
			
		}
			Debug.Log(potstate);

			// Debug.Log("potstate: " + potstate);

	}

	private IEnumerator curseround1(){
		while(true)
		{	
			
			yield return new WaitForSeconds(1);
			potionAcoldtime--;
			

		}
	}

	private IEnumerator curseround2(){
		while(true)
		{	
			// potionB = false;
			yield return new WaitForSeconds(1);
			potionBcoldtime--;

		}
	}

	private IEnumerator curseround3(){
		while(true)
		{	
			// potionC = false;
			yield return new WaitForSeconds(1);
			potionCcoldtime--;

		}
	}

	private IEnumerator curseround4(){
		while(true)
		{	
			// potionD = false;
			yield return new WaitForSeconds(1);
			potionDcoldtime--;

		}
	}

	private IEnumerator potcold(){
		while(true)
		{	
			yield return new WaitForSeconds(10);
			potstate = true;
		}
	}
}
