﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class gobackk : MonoBehaviour {
                 
	// Use this for initialization


	
	// Update is called once per frame
	void FixedUpdate () {


		if(Input.anyKey){
					SceneManager.LoadScene("Startscreen");
				}

	}


}
